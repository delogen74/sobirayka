
  # Собирай-ка UI Kit

  This is a code bundle for Собирай-ка UI Kit. The original project is available at https://www.figma.com/design/SjHGFZpLEyYB8tcWLnbHW7/%D0%A1%D0%BE%D0%B1%D0%B8%D1%80%D0%B0%D0%B9-%D0%BA%D0%B0-UI-Kit.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
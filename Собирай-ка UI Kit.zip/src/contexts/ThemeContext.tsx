import React, { createContext, useContext } from 'react';

interface ThemeContextType {
  theme: 'light' | 'dark';
  color: 'blue' | 'green' | 'purple';
  isEditing: boolean;
  onTextEdit?: (blockId: string, field: string, value: string) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'light',
  color: 'blue',
  isEditing: false
});

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider: React.FC<{
  children: React.ReactNode;
  theme: 'light' | 'dark';
  color: 'blue' | 'green' | 'purple';
  isEditing: boolean;
  onTextEdit?: (blockId: string, field: string, value: string) => void;
}> = ({ children, theme, color, isEditing, onTextEdit }) => {
  return (
    <ThemeContext.Provider value={{ theme, color, isEditing, onTextEdit }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const getColorScheme = (color: 'blue' | 'green' | 'purple') => {
  const schemes = {
    blue: {
      primary: '#3b82f6',
      primaryHover: '#2563eb',
      primaryLight: '#dbeafe',
      primaryDark: '#1e40af'
    },
    green: {
      primary: '#10b981',
      primaryHover: '#059669',
      primaryLight: '#d1fae5',
      primaryDark: '#047857'
    },
    purple: {
      primary: '#a855f7',
      primaryHover: '#9333ea',
      primaryLight: '#f3e8ff',
      primaryDark: '#7e22ce'
    }
  };
  return schemes[color];
};

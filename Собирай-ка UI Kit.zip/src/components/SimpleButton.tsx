import React, { useState } from 'react';
import { useTheme, getColorScheme } from '../contexts/ThemeContext';

interface SimpleButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
}

export function SimpleButton({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  onClick, 
  icon 
}: SimpleButtonProps) {
  const [isHovered, setIsHovered] = useState(false);
  const { color } = useTheme();
  const colorScheme = getColorScheme(color);

  const baseStyle: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '0.5rem',
    justifyContent: 'center',
    borderRadius: '0.5rem',
    transition: 'all 0.2s',
    fontWeight: '500',
    cursor: 'pointer',
    border: 'none',
  };
  
  const variantStyles: Record<string, React.CSSProperties> = {
    primary: {
      backgroundColor: isHovered ? colorScheme.primaryHover : colorScheme.primary,
      color: 'white',
    },
    secondary: {
      backgroundColor: '#f3f4f6',
      color: '#111827',
      border: '1px solid #d1d5db',
    },
    outline: {
      backgroundColor: isHovered ? colorScheme.primaryLight : 'transparent',
      color: colorScheme.primary,
      border: `2px solid ${colorScheme.primary}`,
    },
    ghost: {
      backgroundColor: isHovered ? '#f3f4f6' : 'transparent',
      color: '#4b5563',
    }
  };
  
  const sizeStyles: Record<string, React.CSSProperties> = {
    sm: { padding: '0.375rem 0.75rem', fontSize: '0.875rem' },
    md: { padding: '0.625rem 1.25rem', fontSize: '1rem' },
    lg: { padding: '0.75rem 1.5rem', fontSize: '1.125rem' }
  };
  
  const style = {
    ...baseStyle,
    ...variantStyles[variant],
    ...sizeStyles[size],
  };
  
  return (
    <button
      onClick={onClick}
      style={style}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {icon && <span>{icon}</span>}
      {children}
    </button>
  );
}
import React from 'react';
import { Sun, Moon } from 'lucide-react';

interface ThemeControlsProps {
  theme: 'light' | 'dark';
  color: 'blue' | 'green' | 'purple';
  onThemeChange: (theme: 'light' | 'dark') => void;
  onColorChange: (color: 'blue' | 'green' | 'purple') => void;
}

export function ThemeControls({ theme, color, onThemeChange, onColorChange }: ThemeControlsProps) {
  const colors = [
    { id: 'blue' as const, label: 'Синий', bg: '#3b82f6' },
    { id: 'green' as const, label: 'Зеленый', bg: '#10b981' },
    { id: 'purple' as const, label: 'Фиолетовый', bg: '#a855f7' }
  ];

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '0.75rem'
    }}>
      <div style={{
        display: 'flex',
        gap: '0.5rem',
        backgroundColor: '#f3f4f6',
        padding: '0.25rem',
        borderRadius: '0.5rem',
        border: '1px solid #e5e7eb'
      }}>
        {colors.map((c) => (
          <button
            key={c.id}
            onClick={() => onColorChange(c.id)}
            style={{
              width: '2rem',
              height: '2rem',
              borderRadius: '0.375rem',
              transition: 'all 0.2s',
              backgroundColor: c.bg,
              opacity: color === c.id ? 1 : 0.6,
              border: color === c.id ? '2px solid #111827' : 'none',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => {
              if (color !== c.id) {
                e.currentTarget.style.opacity = '1';
              }
            }}
            onMouseLeave={(e) => {
              if (color !== c.id) {
                e.currentTarget.style.opacity = '0.6';
              }
            }}
            title={c.label}
            aria-label={c.label}
          />
        ))}
      </div>

      <button
        onClick={() => onThemeChange(theme === 'light' ? 'dark' : 'light')}
        style={{
          padding: '0.5rem',
          borderRadius: '0.5rem',
          backgroundColor: '#f3f4f6',
          border: '1px solid #e5e7eb',
          transition: 'all 0.2s',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
        onMouseEnter={(e) => e.currentTarget.style.borderColor = '#3b82f6'}
        onMouseLeave={(e) => e.currentTarget.style.borderColor = '#e5e7eb'}
        aria-label={theme === 'light' ? 'Переключить на темную тему' : 'Переключить на светлую тему'}
      >
        {theme === 'light' ? (
          <Moon size={20} style={{ color: '#111827' }} />
        ) : (
          <Sun size={20} style={{ color: '#111827' }} />
        )}
      </button>
    </div>
  );
}
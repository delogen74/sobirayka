import React, { useState } from 'react';
import { useResponsive } from '../hooks/useResponsive';
import { SimpleButton } from './SimpleButton';
import { getColorScheme } from '../contexts/ThemeContext';
import { Check, X, AlertCircle, Zap, Heart, Star, TrendingUp, Users, Award } from 'lucide-react';

export function Documentation() {
  const { isMobile } = useResponsive();
  const [selectedColor, setSelectedColor] = useState<'blue' | 'green' | 'purple'>('blue');
  const colorScheme = getColorScheme(selectedColor);

  const ColorSwatch = ({ color, name, hex }: { color: string; name: string; hex: string }) => (
    <div style={{ flex: '1', minWidth: isMobile ? '120px' : '150px' }}>
      <div style={{
        width: '100%',
        height: isMobile ? '80px' : '100px',
        backgroundColor: color,
        borderRadius: '0.75rem',
        marginBottom: '0.75rem',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
      }} />
      <p style={{
        fontSize: isMobile ? '0.875rem' : '1rem',
        fontWeight: '600',
        color: '#111827',
        marginBottom: '0.25rem'
      }}>
        {name}
      </p>
      <p style={{
        fontSize: isMobile ? '0.75rem' : '0.875rem',
        color: '#6b7280',
        fontFamily: 'monospace'
      }}>
        {hex}
      </p>
    </div>
  );

  const TypographyExample = ({ tag, size, weight, text }: { tag: string; size: string; weight: string; text: string }) => {
    const Tag = tag as keyof JSX.IntrinsicElements;
    return (
      <div style={{
        padding: isMobile ? '1rem' : '1.5rem',
        backgroundColor: '#f9fafb',
        borderRadius: '0.75rem',
        marginBottom: '1rem'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
          <span style={{
            fontSize: isMobile ? '0.75rem' : '0.875rem',
            color: '#6b7280',
            fontFamily: 'monospace'
          }}>
            {tag.toUpperCase()} • {size} • {weight}
          </span>
        </div>
        <Tag style={{ margin: 0 }}>{text}</Tag>
      </div>
    );
  };

  const ComponentExample = ({ title, description, children }: { title: string; description: string; children: React.ReactNode }) => (
    <div style={{
      padding: isMobile ? '1.5rem' : '2rem',
      backgroundColor: '#f9fafb',
      borderRadius: '1rem',
      marginBottom: '1.5rem'
    }}>
      <h4 style={{
        fontSize: isMobile ? '1rem' : '1.125rem',
        fontWeight: '600',
        color: '#111827',
        marginBottom: '0.5rem'
      }}>
        {title}
      </h4>
      <p style={{
        fontSize: isMobile ? '0.875rem' : '1rem',
        color: '#6b7280',
        marginBottom: '1.5rem'
      }}>
        {description}
      </p>
      <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
        {children}
      </div>
    </div>
  );

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f3f4f6',
      padding: isMobile ? '2rem 1rem' : '3rem 2rem'
    }}>
      <div style={{
        maxWidth: '72rem',
        margin: '0 auto'
      }}>
        {/* Hero Section */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '4rem 3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <div style={{
            display: 'inline-block',
            padding: '0.5rem 1rem',
            backgroundColor: colorScheme.primaryLight,
            color: colorScheme.primary,
            borderRadius: '2rem',
            fontSize: isMobile ? '0.875rem' : '1rem',
            fontWeight: '600',
            marginBottom: '1.5rem'
          }}>
            Версия 2.0 • Production Ready
          </div>
          <h1 style={{
            fontSize: isMobile ? '2.5rem' : '4rem',
            fontWeight: '700',
            lineHeight: '1.1',
            color: '#111827',
            marginBottom: '1.5rem'
          }}>
            UI Kit Конструктор
          </h1>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.25rem',
            lineHeight: '1.75',
            color: '#6b7280',
            maxWidth: '48rem',
            margin: '0 auto 2rem'
          }}>
            Полная дизайн-система для создания современных лендингов. Готовые компоненты, гибкая цветовая схема и адаптивная типографика.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.75rem 1.25rem',
              backgroundColor: '#f3f4f6',
              borderRadius: '0.75rem'
            }}>
              <Check size={20} style={{ color: colorScheme.primary }} />
              <span style={{ fontSize: isMobile ? '0.875rem' : '1rem', color: '#4b5563' }}>7 блоков</span>
            </div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.75rem 1.25rem',
              backgroundColor: '#f3f4f6',
              borderRadius: '0.75rem'
            }}>
              <Check size={20} style={{ color: colorScheme.primary }} />
              <span style={{ fontSize: isMobile ? '0.875rem' : '1rem', color: '#4b5563' }}>3 цветовые схемы</span>
            </div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.75rem 1.25rem',
              backgroundColor: '#f3f4f6',
              borderRadius: '0.75rem'
            }}>
              <Check size={20} style={{ color: colorScheme.primary }} />
              <span style={{ fontSize: isMobile ? '0.875rem' : '1rem', color: '#4b5563' }}>Темная тема</span>
            </div>
          </div>
        </div>

        {/* Color Schemes */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: isMobile ? '2rem' : '2.5rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Цветовые схемы
          </h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            Три готовые цветовые палитры для различных типов проектов. Выберите схему, чтобы увидеть все оттенки.
          </p>

          <div style={{
            display: 'flex',
            gap: '1rem',
            marginBottom: '2rem',
            flexWrap: 'wrap'
          }}>
            <button
              onClick={() => setSelectedColor('blue')}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: selectedColor === 'blue' ? '#3b82f6' : '#f3f4f6',
                color: selectedColor === 'blue' ? 'white' : '#4b5563',
                border: 'none',
                borderRadius: '0.75rem',
                fontSize: isMobile ? '0.875rem' : '1rem',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
            >
              🔵 Синяя
            </button>
            <button
              onClick={() => setSelectedColor('green')}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: selectedColor === 'green' ? '#10b981' : '#f3f4f6',
                color: selectedColor === 'green' ? 'white' : '#4b5563',
                border: 'none',
                borderRadius: '0.75rem',
                fontSize: isMobile ? '0.875rem' : '1rem',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
            >
              🟢 Зеленая
            </button>
            <button
              onClick={() => setSelectedColor('purple')}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: selectedColor === 'purple' ? '#a855f7' : '#f3f4f6',
                color: selectedColor === 'purple' ? 'white' : '#4b5563',
                border: 'none',
                borderRadius: '0.75rem',
                fontSize: isMobile ? '0.875rem' : '1rem',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
            >
              🟣 Фиолетовая
            </button>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(150px, 1fr))',
            gap: '1.5rem'
          }}>
            <ColorSwatch color={colorScheme.primary} name="Primary" hex={colorScheme.primary} />
            <ColorSwatch color={colorScheme.primaryHover} name="Primary Hover" hex={colorScheme.primaryHover} />
            <ColorSwatch color={colorScheme.primaryLight} name="Primary Light" hex={colorScheme.primaryLight} />
            <ColorSwatch color={colorScheme.primaryDark} name="Primary Dark" hex={colorScheme.primaryDark} />
          </div>

          <div style={{
            marginTop: '2rem',
            padding: isMobile ? '1.5rem' : '2rem',
            backgroundColor: '#f9fafb',
            borderRadius: '1rem',
            border: '2px dashed #e5e7eb'
          }}>
            <h4 style={{
              fontSize: isMobile ? '1rem' : '1.125rem',
              fontWeight: '600',
              color: '#111827',
              marginBottom: '1rem'
            }}>
              Рекомендации по использованию:
            </h4>
            <ul style={{
              fontSize: isMobile ? '0.875rem' : '1rem',
              lineHeight: '1.75',
              color: '#4b5563',
              paddingLeft: '1.5rem',
              margin: 0
            }}>
              <li style={{ marginBottom: '0.5rem' }}><strong>Синяя</strong> (#3b82f6) - универсальная, идеальна для B2B, финансовых и корпоративных проектов</li>
              <li style={{ marginBottom: '0.5rem' }}><strong>Зеленая</strong> (#10b981) - экологические проекты, здоровье, wellness, устойчивое развитие</li>
              <li style={{ marginBottom: '0.5rem' }}><strong>Фиолетовая</strong> (#a855f7) - креативные индустрии, инновации, образование, технологии</li>
            </ul>
          </div>
        </div>

        {/* Typography */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: isMobile ? '2rem' : '2.5rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Типографика
          </h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            Система шрифтов основана на Inter и DM Sans с адаптивными размерами для всех устройств.
          </p>

          <TypographyExample
            tag="h1"
            size={isMobile ? '2rem' : '3rem'}
            weight="700"
            text="Заголовок H1 - Главный акцент страницы"
          />
          <TypographyExample
            tag="h2"
            size={isMobile ? '1.875rem' : '2.25rem'}
            weight="700"
            text="Заголовок H2 - Секции и разделы"
          />
          <TypographyExample
            tag="h3"
            size={isMobile ? '1.25rem' : '1.5rem'}
            weight="600"
            text="Заголовок H3 - Подразделы и карточки"
          />
          <TypographyExample
            tag="p"
            size={isMobile ? '0.875rem' : '1rem'}
            weight="400"
            text="Основной текст - Используется для параграфов, описаний и контента. Оптимальная читаемость на всех устройствах."
          />

          <div style={{
            marginTop: '2rem',
            display: 'grid',
            gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
            gap: '1.5rem'
          }}>
            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#f9fafb',
              borderRadius: '1rem'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '1rem',
                fontFamily: 'Inter, sans-serif'
              }}>
                Inter
              </h4>
              <p style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                color: '#6b7280',
                fontFamily: 'Inter, sans-serif',
                lineHeight: '1.75'
              }}>
                Современный sans-serif шрифт, используется для заголовков и интерфейсных элементов. Отличная читаемость на любых экранах.
              </p>
            </div>
            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#f9fafb',
              borderRadius: '1rem'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '1rem',
                fontFamily: '"DM Sans", sans-serif'
              }}>
                DM Sans
              </h4>
              <p style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                color: '#6b7280',
                fontFamily: '"DM Sans", sans-serif',
                lineHeight: '1.75'
              }}>
                Геометричный шрифт с хорошей читаемостью, используется для основного текста и акцентных элементов.
              </p>
            </div>
          </div>
        </div>

        {/* Components */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: isMobile ? '2rem' : '2.5rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Компоненты
          </h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            Готовые UI компоненты с различными вариантами и состояниями.
          </p>

          <ComponentExample
            title="Кнопки"
            description="Основные и вспомогательные кнопки для всех интерактивных элементов"
          >
            <button style={{
              padding: isMobile ? '0.625rem 1.25rem' : '0.75rem 1.5rem',
              backgroundColor: colorScheme.primary,
              color: 'white',
              border: 'none',
              borderRadius: '0.75rem',
              fontSize: isMobile ? '0.875rem' : '1rem',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}>
              Primary Button
            </button>
            <button style={{
              padding: isMobile ? '0.625rem 1.25rem' : '0.75rem 1.5rem',
              backgroundColor: 'transparent',
              color: colorScheme.primary,
              border: `2px solid ${colorScheme.primary}`,
              borderRadius: '0.75rem',
              fontSize: isMobile ? '0.875rem' : '1rem',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}>
              Secondary Button
            </button>
            <button style={{
              padding: isMobile ? '0.625rem 1.25rem' : '0.75rem 1.5rem',
              backgroundColor: '#f3f4f6',
              color: '#4b5563',
              border: 'none',
              borderRadius: '0.75rem',
              fontSize: isMobile ? '0.875rem' : '1rem',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}>
              Ghost Button
            </button>
          </ComponentExample>

          <ComponentExample
            title="Карточки"
            description="Контейнеры для группировки связанного контента"
          >
            <div style={{
              width: '100%',
              maxWidth: isMobile ? '100%' : '300px',
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '1rem',
              boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
              transition: 'all 0.3s'
            }}>
              <div style={{
                width: '3rem',
                height: '3rem',
                backgroundColor: colorScheme.primaryLight,
                borderRadius: '0.75rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1rem'
              }}>
                <Zap size={24} style={{ color: colorScheme.primary }} />
              </div>
              <h4 style={{
                fontSize: isMobile ? '1.125rem' : '1.25rem',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '0.5rem'
              }}>
                Заголовок карточки
              </h4>
              <p style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.75',
                color: '#6b7280',
                marginBottom: 0
              }}>
                Описание карточки с основной информацией о функции или преимуществе.
              </p>
            </div>
          </ComponentExample>

          <ComponentExample
            title="Иконки"
            description="Набор иконок Lucide React для визуального усиления контента"
          >
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              {[
                { icon: Check, label: 'Check' },
                { icon: X, label: 'Close' },
                { icon: AlertCircle, label: 'Alert' },
                { icon: Heart, label: 'Heart' },
                { icon: Star, label: 'Star' },
                { icon: TrendingUp, label: 'Trending' },
                { icon: Users, label: 'Users' },
                { icon: Award, label: 'Award' }
              ].map(({ icon: Icon, label }) => (
                <div key={label} style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.5rem',
                  padding: '1rem',
                  backgroundColor: '#f9fafb',
                  borderRadius: '0.75rem'
                }}>
                  <Icon size={24} style={{ color: colorScheme.primary }} />
                  <span style={{
                    fontSize: '0.75rem',
                    color: '#6b7280'
                  }}>
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </ComponentExample>

          <ComponentExample
            title="Значки (Badges)"
            description="Метки для статусов, категорий и акцентов"
          >
            <span style={{
              padding: '0.375rem 0.75rem',
              backgroundColor: colorScheme.primaryLight,
              color: colorScheme.primary,
              borderRadius: '0.5rem',
              fontSize: isMobile ? '0.75rem' : '0.875rem',
              fontWeight: '600'
            }}>
              Primary Badge
            </span>
            <span style={{
              padding: '0.375rem 0.75rem',
              backgroundColor: '#dcfce7',
              color: '#16a34a',
              borderRadius: '0.5rem',
              fontSize: isMobile ? '0.75rem' : '0.875rem',
              fontWeight: '600'
            }}>
              Success
            </span>
            <span style={{
              padding: '0.375rem 0.75rem',
              backgroundColor: '#fef3c7',
              color: '#d97706',
              borderRadius: '0.5rem',
              fontSize: isMobile ? '0.75rem' : '0.875rem',
              fontWeight: '600'
            }}>
              Warning
            </span>
            <span style={{
              padding: '0.375rem 0.75rem',
              backgroundColor: '#fee2e2',
              color: '#dc2626',
              borderRadius: '0.5rem',
              fontSize: isMobile ? '0.75rem' : '0.875rem',
              fontWeight: '600'
            }}>
              Error
            </span>
          </ComponentExample>
        </div>

        {/* Blocks */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: isMobile ? '2rem' : '2.5rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Блоки лендинга
          </h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            7 готовых блоков для создания полноценных лендингов. Каждый блок полностью адаптивен и настраиваем.
          </p>

          <div style={{
            display: 'grid',
            gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '1.5rem'
          }}>
            {[
              {
                name: 'Header',
                description: 'Навигационная панель с логотипом и меню',
                icon: '📋',
                limit: 'один на страницу'
              },
              {
                name: 'Основной экран',
                description: 'Главная секция с заголовком, описанием и CTA',
                icon: '🚀',
                limit: 'без ограничений'
              },
              {
                name: 'Преимущества',
                description: 'Блок преимуществ с иконками и описаниями',
                icon: '✨',
                limit: 'без ограничений'
              },
              {
                name: 'Pricing',
                description: 'Тарифные планы с ценами и функциями',
                icon: '💰',
                limit: 'без ограничений'
              },
              {
                name: 'Testimonials',
                description: 'Отзывы клиентов с аватарами и рейтингом',
                icon: '💬',
                limit: 'без ограничений'
              },
              {
                name: 'Contact',
                description: 'Форма обратной связи с полями ввода',
                icon: '📧',
                limit: 'без ограничений'
              },
              {
                name: 'Footer',
                description: 'Подвал с ссылками и информацией',
                icon: '🔗',
                limit: 'один на страницу'
              }
            ].map((block, index) => (
              <div key={index} style={{
                padding: isMobile ? '1.5rem' : '2rem',
                backgroundColor: '#f9fafb',
                border: '1px solid #e5e7eb',
                borderRadius: '1rem',
                transition: 'all 0.3s'
              }}>
                <div style={{
                  fontSize: '2.5rem',
                  marginBottom: '1rem'
                }}>
                  {block.icon}
                </div>
                <h4 style={{
                  fontSize: isMobile ? '1.125rem' : '1.25rem',
                  fontWeight: '600',
                  color: '#111827',
                  marginBottom: '0.5rem'
                }}>
                  {block.name}
                </h4>
                <p style={{
                  fontSize: isMobile ? '0.875rem' : '1rem',
                  lineHeight: '1.75',
                  color: '#6b7280',
                  marginBottom: '1rem'
                }}>
                  {block.description}
                </p>
                <span style={{
                  fontSize: '0.75rem',
                  color: '#9ca3af',
                  fontStyle: 'italic'
                }}>
                  {block.limit}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Spacing & Layout */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: isMobile ? '2rem' : '2.5rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Отступы и сетка
          </h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            Система отступов обеспечивает консистентность и визуальный ритм на всех устройствах.
          </p>

          <div style={{
            display: 'grid',
            gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
            gap: '1.5rem',
            marginBottom: '2rem'
          }}>
            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#f9fafb',
              borderRadius: '1rem'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '1rem'
              }}>
                Desktop (&gt; 1024px)
              </h4>
              <ul style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.75',
                color: '#4b5563',
                paddingLeft: '1.5rem',
                margin: 0
              }}>
                <li style={{ marginBottom: '0.5rem' }}>Вертикальные: 6rem (96px)</li>
                <li style={{ marginBottom: '0.5rem' }}>Горизонтальные: 1.5rem (24px)</li>
                <li style={{ marginBottom: '0.5rem' }}>Максимальная ширина: 1280px</li>
              </ul>
            </div>
            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#f9fafb',
              borderRadius: '1rem'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '1rem'
              }}>
                Mobile (&lt; 768px)
              </h4>
              <ul style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.75',
                color: '#4b5563',
                paddingLeft: '1.5rem',
                margin: 0
              }}>
                <li style={{ marginBottom: '0.5rem' }}>Вертикальные: 3rem (48px)</li>
                <li style={{ marginBottom: '0.5rem' }}>Горизонтальные: 1rem (16px)</li>
                <li style={{ marginBottom: '0.5rem' }}>Максимальная ширина: 100%</li>
              </ul>
            </div>
          </div>

          <div style={{
            padding: isMobile ? '1.5rem' : '2rem',
            backgroundColor: colorScheme.primaryLight,
            borderRadius: '1rem',
            borderLeft: `4px solid ${colorScheme.primary}`
          }}>
            <h4 style={{
              fontSize: isMobile ? '1rem' : '1.125rem',
              fontWeight: '600',
              color: '#111827',
              marginBottom: '0.75rem'
            }}>
              💡 Адаптивный дизайн
            </h4>
            <p style={{
              fontSize: isMobile ? '0.875rem' : '1rem',
              lineHeight: '1.75',
              color: '#4b5563',
              margin: 0
            }}>
              Все блоки автоматически адаптируются под размер экрана. Контент перестраивается из горизонтальной сетки в вертикальную на мобильных устройствах для оптимальной читаемости.
            </p>
          </div>
        </div>

        {/* Best Practices */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: isMobile ? '2rem' : '2.5rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Лучшие практики
          </h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            Рекомендации по созданию эффективных лендингов с нашей дизайн-системой.
          </p>

          <div style={{
            display: 'grid',
            gridTemplateColumns: isMobile ? '1fr' : 'repeat(3, 1fr)',
            gap: '1.5rem'
          }}>
            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#eff6ff',
              borderRadius: '1rem',
              border: '1px solid #dbeafe'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#1e40af',
                marginBottom: '1rem'
              }}>
                🎯 Структура
              </h4>
              <ol style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.75',
                color: '#4b5563',
                paddingLeft: '1.25rem',
                margin: 0
              }}>
                <li style={{ marginBottom: '0.5rem' }}>Header сверху</li>
                <li style={{ marginBottom: '0.5rem' }}>Основной экран для первого впечатления</li>
                <li style={{ marginBottom: '0.5rem' }}>Value Props для УТП</li>
                <li style={{ marginBottom: '0.5rem' }}>Pricing для монетизации</li>
                <li style={{ marginBottom: '0.5rem' }}>Footer внизу</li>
              </ol>
            </div>

            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#f0fdf4',
              borderRadius: '1rem',
              border: '1px solid #dcfce7'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#166534',
                marginBottom: '1rem'
              }}>
                🎨 Цвета
              </h4>
              <ul style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.75',
                color: '#4b5563',
                paddingLeft: '1.25rem',
                margin: 0
              }}>
                <li style={{ marginBottom: '0.5rem' }}>Синяя для B2B</li>
                <li style={{ marginBottom: '0.5rem' }}>Зеленая для eco/health</li>
                <li style={{ marginBottom: '0.5rem' }}>Фиолетовая для креатива</li>
                <li style={{ marginBottom: '0.5rem' }}>Темная тема для tech</li>
              </ul>
            </div>

            <div style={{
              padding: isMobile ? '1.5rem' : '2rem',
              backgroundColor: '#faf5ff',
              borderRadius: '1rem',
              border: '1px solid #f3e8ff'
            }}>
              <h4 style={{
                fontSize: isMobile ? '1rem' : '1.125rem',
                fontWeight: '600',
                color: '#6b21a8',
                marginBottom: '1rem'
              }}>
                📱 Адаптивность
              </h4>
              <ul style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.75',
                color: '#4b5563',
                paddingLeft: '1.25rem',
                margin: 0
              }}>
                <li style={{ marginBottom: '0.5rem' }}>Тестируйте на мобильных</li>
                <li style={{ marginBottom: '0.5rem' }}>Оптимизируйте изображения</li>
                <li style={{ marginBottom: '0.5rem' }}>Проверяйте все breakpoints</li>
                <li style={{ marginBottom: '0.5rem' }}>Упрощайте навигацию</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '1.5rem',
          padding: isMobile ? '2rem 1.5rem' : '3rem',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <div style={{
            width: '4rem',
            height: '4rem',
            backgroundColor: colorScheme.primaryLight,
            borderRadius: '1rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1.5rem',
            fontSize: '2rem'
          }}>
            📚
          </div>
          <h3 style={{
            fontSize: isMobile ? '1.5rem' : '2rem',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '1rem'
          }}>
            Нужна помощь?
          </h3>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: '#6b7280',
            marginBottom: '1.5rem',
            maxWidth: '32rem',
            margin: '0 auto 1.5rem'
          }}>
            Свяжитесь с нами для вопросов, предложений или технической поддержки.
          </p>
          <div style={{
            display: 'inline-block',
            padding: '1rem 2rem',
            backgroundColor: '#f9fafb',
            borderRadius: '0.75rem'
          }}>
            <p style={{
              fontSize: isMobile ? '0.875rem' : '1rem',
              color: '#4b5563',
              margin: 0
            }}>
              📧 support@landingbuilder.ru
            </p>
          </div>
          <div style={{
            marginTop: '2rem',
            paddingTop: '2rem',
            borderTop: '1px solid #e5e7eb',
            fontSize: isMobile ? '0.75rem' : '0.875rem',
            color: '#9ca3af'
          }}>
            <p style={{ margin: '0.25rem 0' }}>UI Kit Конструктор v2.0</p>
            <p style={{ margin: '0.25rem 0' }}>Последнее обновление: Декабрь 2025</p>
            <p style={{ margin: '0.25rem 0' }}>Production Ready ✅</p>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { 
  LayoutGrid, 
  FileText, 
  Award, 
  CreditCard, 
  MessageCircle, 
  Mail, 
  AlignCenter 
} from 'lucide-react';
import { useResponsive } from '../hooks/useResponsive';

interface BlockLibraryProps {
  onAddBlock: (blockType: string) => void;
  hasHeader: boolean;
  hasFooter: boolean;
}

const blockTypes = [
  {
    id: 'header',
    name: 'Хедер',
    description: 'Навигация и лого',
    icon: LayoutGrid,
    limit: true
  },
  {
    id: 'hero',
    name: 'Основной экран',
    description: 'Главный экран',
    icon: FileText,
    limit: false
  },
  {
    id: 'valueProps',
    name: 'Преимущества',
    description: 'Блок с иконками',
    icon: Award,
    limit: false
  },
  {
    id: 'pricing',
    name: 'Тарифы',
    description: 'Блок с ценами',
    icon: CreditCard,
    limit: false
  },
  {
    id: 'testimonials',
    name: 'Отзывы',
    description: 'Отзывы клиентов',
    icon: MessageCircle,
    limit: false
  },
  {
    id: 'contact',
    name: 'Контакты',
    description: 'Форма связи',
    icon: Mail,
    limit: false
  },
  {
    id: 'footer',
    name: 'Футер',
    description: 'Подвал с ссылками',
    icon: AlignCenter,
    limit: true
  }
];

export function BlockLibrary({ onAddBlock, hasHeader, hasFooter }: BlockLibraryProps) {
  const { isMobile } = useResponsive();
  
  const isBlockDisabled = (blockId: string) => {
    if (blockId === 'header' && hasHeader) return true;
    if (blockId === 'footer' && hasFooter) return true;
    return false;
  };

  return (
    <div style={{
      width: '100%',
      height: '100%',
      overflowY: 'auto',
      backgroundColor: '#f9fafb'
    }}>
      <div style={{ padding: isMobile ? '1rem' : '1.5rem' }}>
        <h3 style={{
          fontSize: isMobile ? '1.25rem' : '1.5rem',
          fontWeight: '600',
          lineHeight: '2rem',
          color: '#111827',
          marginBottom: '0.5rem'
        }}>Библиотека блоков</h3>
        <p style={{
          fontSize: '0.875rem',
          color: '#4b5563',
          marginBottom: '1.5rem'
        }}>
          Выберите блоки для вашего лендинга
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {blockTypes.map((block) => {
            const Icon = block.icon;
            const disabled = isBlockDisabled(block.id);

            return (
              <button
                key={block.id}
                onClick={() => !disabled && onAddBlock(block.id)}
                disabled={disabled}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: isMobile ? '0.875rem' : '1rem',
                  borderRadius: '0.75rem',
                  border: '1px solid',
                  borderColor: disabled ? '#d1d5db' : '#e5e7eb',
                  backgroundColor: disabled ? '#e5e7eb' : 'white',
                  opacity: disabled ? 0.5 : 1,
                  cursor: disabled ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => {
                  if (!disabled) {
                    e.currentTarget.style.borderColor = '#3b82f6';
                    e.currentTarget.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!disabled) {
                    e.currentTarget.style.borderColor = '#e5e7eb';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                  <div style={{
                    width: isMobile ? '2rem' : '2.5rem',
                    height: isMobile ? '2rem' : '2.5rem',
                    borderRadius: '0.5rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                    backgroundColor: disabled ? '#d1d5db' : '#dbeafe'
                  }}>
                    <Icon 
                      size={isMobile ? 18 : 20} 
                      style={{ color: disabled ? '#9ca3af' : '#3b82f6' }}
                    />
                  </div>
                  <div style={{ flex: 1 }}>
                    <h4 style={{
                      fontSize: '0.875rem',
                      fontWeight: '600',
                      color: '#111827',
                      marginBottom: '0.25rem'
                    }}>
                      {block.name}
                    </h4>
                    <p style={{
                      fontSize: '0.75rem',
                      lineHeight: '1.5',
                      color: '#6b7280',
                      margin: 0
                    }}>
                      {block.description}
                      {disabled && ' (добавлен)'}
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
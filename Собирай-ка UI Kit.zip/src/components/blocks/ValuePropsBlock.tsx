import React from 'react';
import { Zap, Shield, Smartphone } from 'lucide-react';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';

interface ValuePropsBlockProps {
  id?: string;
  data?: any;
}

export function ValuePropsBlock({ id, data }: ValuePropsBlockProps) {
  const { theme, color, isEditing, onTextEdit } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);

  const defaultData = {
    title: 'Преимущества',
    subtitle: 'Всё что нужно для создания эффективных лендингов',
    features: [
      {
        title: 'Быстрый запуск',
        description: 'Создавайте и публикуйте лендинги за минуты, а не дни'
      },
      {
        title: 'Безопасность',
        description: 'Защита данных и надежное хранение вашего контента'
      },
      {
        title: 'Адаптивность',
        description: 'Идеальный вид на всех устройствах и экранах'
      }
    ]
  };

  const content = {
    title: data?.title || defaultData.title,
    subtitle: data?.subtitle || defaultData.subtitle,
    features: data?.features || defaultData.features
  };
  const icons = [Zap, Shield, Smartphone];

  const handleEdit = (field: string, value: string) => {
    if (id && onTextEdit) {
      onTextEdit(id, field, value);
    }
  };

  const bgColor = theme === 'dark' ? '#1f2937' : '#f9fafb';
  const cardBgColor = theme === 'dark' ? '#111827' : 'white';
  const borderColor = theme === 'dark' ? '#374151' : '#e5e7eb';
  const titleColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const subtitleColor = theme === 'dark' ? '#d1d5db' : '#4b5563';

  return (
    <section style={{
      width: '100%',
      backgroundColor: bgColor,
      transition: 'background-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '3rem 1rem' : '6rem 1.5rem'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: isMobile ? '2.5rem' : '4rem'
        }}>
          {isEditing ? (
            <input
              type="text"
              value={content.title}
              onChange={(e) => handleEdit('title', e.target.value)}
              style={{
                width: '100%',
                fontSize: isMobile ? '1.875rem' : '2.25rem',
                fontWeight: '700',
                lineHeight: '1.2',
                maxWidth: '28rem',
                margin: '0 auto',
                color: titleColor,
                backgroundColor: 'transparent',
                borderBottom: `2px dashed ${colorScheme.primary}`,
                padding: '0.5rem',
                textAlign: 'center',
                outline: 'none',
                border: 'none',
                borderBottom: `2px dashed ${colorScheme.primary}`,
                fontFamily: 'inherit'
              }}
            />
          ) : (
            <h2 style={{
              fontSize: isMobile ? '1.875rem' : '2.25rem',
              fontWeight: '700',
              lineHeight: '1.2',
              color: titleColor,
              marginBottom: '1rem',
              transition: 'color 0.3s'
            }}>{content.title}</h2>
          )}
          
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: subtitleColor,
            maxWidth: '42rem',
            margin: '0 auto',
            transition: 'color 0.3s'
          }}>
            {content.subtitle}
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: isMobile ? '1.5rem' : '2rem'
        }}>
          {content.features.map((feature: any, index: number) => {
            const Icon = icons[index];
            return (
              <div
                key={index}
                style={{
                  backgroundColor: cardBgColor,
                  padding: isMobile ? '1.5rem' : '2rem',
                  borderRadius: '1rem',
                  border: `1px solid ${borderColor}`,
                  transition: 'all 0.3s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = colorScheme.primary;
                  e.currentTarget.style.transform = 'translateY(-4px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = borderColor;
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                <div style={{
                  width: isMobile ? '2.5rem' : '3rem',
                  height: isMobile ? '2.5rem' : '3rem',
                  borderRadius: '0.75rem',
                  backgroundColor: colorScheme.primaryLight,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '1.5rem'
                }}>
                  <Icon style={{ color: colorScheme.primary }} size={isMobile ? 20 : 24} />
                </div>
                <h3 style={{
                  fontSize: isMobile ? '1.25rem' : '1.5rem',
                  fontWeight: '600',
                  lineHeight: '1.375',
                  color: titleColor,
                  marginBottom: '0.75rem',
                  transition: 'color 0.3s'
                }}>
                  {feature.title}
                </h3>
                <p style={{
                  fontSize: isMobile ? '0.875rem' : '1rem',
                  lineHeight: '1.625',
                  color: subtitleColor,
                  transition: 'color 0.3s'
                }}>
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
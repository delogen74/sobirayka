import React from 'react';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';

interface FooterBlockProps {
  id?: string;
  data?: any;
}

export function FooterBlock({ id, data }: FooterBlockProps) {
  const { theme, color } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);

  const defaultData = {
    logo: 'Landing Builder',
    tagline: 'Создавайте красивые лендинги за минуты',
    columns: [
      {
        title: 'Продукт',
        links: ['Возможности', 'Тарифы', 'Шаблоны', 'Интеграции']
      },
      {
        title: 'Компания',
        links: ['О нас', 'Блог', 'Карьера', 'Контакты']
      },
      {
        title: 'Поддержка',
        links: ['Документация', 'API', 'Статус', 'Помощь']
      }
    ],
    copyright: '© 2025 Landing Builder. Все права защищены.'
  };

  const content = {
    logo: data?.logo || defaultData.logo,
    tagline: data?.tagline || defaultData.tagline,
    columns: data?.columns || defaultData.columns,
    copyright: data?.copyright || defaultData.copyright
  };

  const bgColor = theme === 'dark' ? '#1f2937' : '#f9fafb';
  const borderColor = theme === 'dark' ? '#374151' : '#e5e7eb';
  const titleColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const textColor = theme === 'dark' ? '#d1d5db' : '#4b5563';
  const mutedColor = theme === 'dark' ? '#9ca3af' : '#9ca3af';

  return (
    <footer style={{
      width: '100%',
      backgroundColor: bgColor,
      borderTop: `1px solid ${borderColor}`,
      transition: 'background-color 0.3s, border-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '2.5rem 1rem' : '4rem 1.5rem'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: isMobile ? '2rem' : '2rem',
          marginBottom: isMobile ? '2rem' : '3rem'
        }}>
          <div style={{ gridColumn: isMobile ? 'span 1' : 'span 2' }}>
            <h4 style={{
              fontSize: isMobile ? '1.125rem' : '1.25rem',
              fontWeight: '700',
              color: titleColor,
              marginBottom: '0.75rem',
              transition: 'color 0.3s'
            }}>{content.logo}</h4>
            <p style={{
              fontSize: isMobile ? '0.875rem' : '1rem',
              lineHeight: '1.625',
              color: textColor,
              maxWidth: '20rem',
              transition: 'color 0.3s'
            }}>
              {content.tagline}
            </p>
          </div>

          {content.columns.map((column: any, index: number) => (
            <div key={index}>
              <h4 style={{
                fontSize: '0.875rem',
                fontWeight: '600',
                color: titleColor,
                marginBottom: '1rem',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                transition: 'color 0.3s'
              }}>
                {column.title}
              </h4>
              <ul style={{
                listStyle: 'none',
                padding: 0,
                margin: 0
              }}>
                {column.links.map((link: string, linkIndex: number) => (
                  <li key={linkIndex} style={{ marginBottom: '0.75rem' }}>
                    <a
                      href="#"
                      style={{
                        fontSize: '0.875rem',
                        color: textColor,
                        textDecoration: 'none',
                        transition: 'color 0.2s'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.color = colorScheme.primary}
                      onMouseLeave={(e) => e.currentTarget.style.color = textColor}
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div style={{
          paddingTop: '2rem',
          borderTop: `1px solid ${borderColor}`,
          transition: 'border-color 0.3s'
        }}>
          <p style={{
            fontSize: '0.875rem',
            color: mutedColor,
            textAlign: 'center',
            margin: 0
          }}>
            {content.copyright}
          </p>
        </div>
      </div>
    </footer>
  );
}
import React, { useState } from 'react';
import { SimpleButton } from '../SimpleButton';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';
import { Menu } from 'lucide-react';

interface HeaderProps {
  id?: string;
  data?: any;
}

export function HeaderBlock({ id, data }: HeaderProps) {
  const { theme, color, isEditing, onTextEdit } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const [content] = useState({
    logo: 'BrandName',
    nav: ['О нас', 'Услуги', 'Цены', 'Контакты'],
    ctaText: 'Начать'
  });

  const currentContent = {
    logo: data?.logo || content.logo,
    nav: data?.nav || content.nav,
    ctaText: data?.ctaText || content.ctaText
  };

  const handleEdit = (field: string, value: string) => {
    if (id && onTextEdit) {
      onTextEdit(id, field, value);
    }
  };

  const bgColor = theme === 'dark' ? '#1f2937' : 'white';
  const borderColor = theme === 'dark' ? '#374151' : '#e5e7eb';
  const logoColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const navColor = theme === 'dark' ? '#d1d5db' : '#4b5563';

  return (
    <header style={{
      width: '100%',
      borderBottom: `1px solid ${borderColor}`,
      backgroundColor: bgColor,
      transition: 'background-color 0.3s, border-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '0 1rem' : '0 1.5rem'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: isMobile ? '4rem' : '5rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            {isEditing ? (
              <input
                type="text"
                value={currentContent.logo}
                onChange={(e) => handleEdit('logo', e.target.value)}
                style={{
                  fontSize: isMobile ? '1.125rem' : '1.25rem',
                  fontWeight: '700',
                  color: logoColor,
                  backgroundColor: 'transparent',
                  borderBottom: `1px dashed ${colorScheme.primary}`,
                  padding: '0.25rem',
                  outline: 'none',
                  border: 'none',
                  borderBottom: `1px dashed ${colorScheme.primary}`,
                  fontFamily: 'inherit'
                }}
              />
            ) : (
              <div style={{
                fontSize: isMobile ? '1.125rem' : '1.25rem',
                fontWeight: '700',
                color: logoColor,
                transition: 'color 0.3s'
              }}>{currentContent.logo}</div>
            )}
          </div>

          {isMobile ? (
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              style={{
                padding: '0.5rem',
                backgroundColor: 'transparent',
                border: 'none',
                cursor: 'pointer',
                color: navColor
              }}
            >
              <Menu size={24} />
            </button>
          ) : (
            <>
              <nav style={{
                display: 'flex',
                alignItems: 'center',
                gap: '2rem'
              }}>
                {currentContent.nav.map((item: string, index: number) => (
                  <a
                    key={index}
                    href="#"
                    style={{
                      fontSize: '1rem',
                      color: navColor,
                      textDecoration: 'none',
                      transition: 'color 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = colorScheme.primary}
                    onMouseLeave={(e) => e.currentTarget.style.color = navColor}
                  >
                    {item}
                  </a>
                ))}
              </nav>

              <SimpleButton size="sm">
                {currentContent.ctaText}
              </SimpleButton>
            </>
          )}
        </div>

        {/* Mobile Menu */}
        {isMobile && mobileMenuOpen && (
          <div style={{
            paddingBottom: '1rem',
            borderTop: `1px solid ${borderColor}`,
            paddingTop: '1rem'
          }}>
            <nav style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem'
            }}>
              {currentContent.nav.map((item: string, index: number) => (
                <a
                  key={index}
                  href="#"
                  style={{
                    fontSize: '1rem',
                    color: navColor,
                    textDecoration: 'none',
                    padding: '0.5rem',
                    transition: 'color 0.2s'
                  }}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
              <SimpleButton size="sm">
                {currentContent.ctaText}
              </SimpleButton>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
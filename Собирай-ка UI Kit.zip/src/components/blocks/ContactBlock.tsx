import React from 'react';
import { SimpleButton } from '../SimpleButton';
import { Mail, Phone, MapPin } from 'lucide-react';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';

interface ContactBlockProps {
  id?: string;
  data?: any;
}

export function ContactBlock({ id, data }: ContactBlockProps) {
  const { theme, color } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);

  const defaultData = {
    title: 'Свяжитесь с нами',
    subtitle: 'Мы всегда рады помочь и ответить на ваши вопросы',
    email: 'hello@landingbuilder.ru',
    phone: '+7 (495) 123-45-67',
    address: 'Москва, ул. Примерная, д. 1'
  };

  const content = data || defaultData;

  const bgColor = theme === 'dark' ? '#111827' : 'white';
  const cardBgColor = theme === 'dark' ? '#1f2937' : '#f9fafb';
  const inputBgColor = theme === 'dark' ? '#111827' : 'white';
  const borderColor = theme === 'dark' ? '#374151' : '#e5e7eb';
  const titleColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const subtitleColor = theme === 'dark' ? '#d1d5db' : '#4b5563';

  const contactItems = [
    { icon: Mail, label: 'Email', value: content.email },
    { icon: Phone, label: 'Телефон', value: content.phone },
    { icon: MapPin, label: 'Адрес', value: content.address }
  ];

  return (
    <section style={{
      width: '100%',
      backgroundColor: bgColor,
      transition: 'background-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '3rem 1rem' : '6rem 1.5rem'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: isMobile ? '2.5rem' : '4rem'
        }}>
          <h2 style={{
            fontSize: isMobile ? '1.875rem' : '2.25rem',
            fontWeight: '700',
            lineHeight: '1.2',
            color: titleColor,
            marginBottom: '1rem',
            transition: 'color 0.3s'
          }}>{content.title}</h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: subtitleColor,
            maxWidth: '42rem',
            margin: '0 auto',
            transition: 'color 0.3s'
          }}>
            {content.subtitle}
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: isMobile ? '2rem' : '3rem'
        }}>
          <div>
            {contactItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '1rem',
                  marginBottom: index < contactItems.length - 1 ? '2rem' : 0
                }}>
                  <div style={{
                    width: isMobile ? '2.5rem' : '3rem',
                    height: isMobile ? '2.5rem' : '3rem',
                    borderRadius: '0.75rem',
                    backgroundColor: colorScheme.primaryLight,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0
                  }}>
                    <Icon style={{ color: colorScheme.primary }} size={isMobile ? 20 : 24} />
                  </div>
                  <div>
                    <h4 style={{
                      fontSize: isMobile ? '1.125rem' : '1.25rem',
                      fontWeight: '600',
                      color: titleColor,
                      marginBottom: '0.5rem',
                      transition: 'color 0.3s'
                    }}>{item.label}</h4>
                    <p style={{
                      fontSize: isMobile ? '0.875rem' : '1rem',
                      lineHeight: '1.625',
                      color: subtitleColor,
                      transition: 'color 0.3s'
                    }}>{item.value}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{
            backgroundColor: cardBgColor,
            padding: isMobile ? '1.5rem' : '2rem',
            borderRadius: '1rem',
            border: `1px solid ${borderColor}`,
            transition: 'background-color 0.3s, border-color 0.3s'
          }}>
            <form>
              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{
                  display: 'block',
                  fontSize: isMobile ? '0.875rem' : '1rem',
                  fontWeight: '500',
                  color: titleColor,
                  marginBottom: '0.5rem',
                  transition: 'color 0.3s'
                }}>
                  Ваше имя
                </label>
                <input
                  type="text"
                  style={{
                    width: '100%',
                    padding: isMobile ? '0.625rem 0.875rem' : '0.75rem 1rem',
                    fontSize: isMobile ? '0.875rem' : '1rem',
                    borderRadius: '0.5rem',
                    backgroundColor: inputBgColor,
                    border: `1px solid ${borderColor}`,
                    color: titleColor,
                    outline: 'none',
                    transition: 'border-color 0.2s, background-color 0.3s, color 0.3s'
                  }}
                  placeholder="Иван Иванов"
                  onFocus={(e) => e.currentTarget.style.borderColor = colorScheme.primary}
                  onBlur={(e) => e.currentTarget.style.borderColor = borderColor}
                />
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{
                  display: 'block',
                  fontSize: isMobile ? '0.875rem' : '1rem',
                  fontWeight: '500',
                  color: titleColor,
                  marginBottom: '0.5rem',
                  transition: 'color 0.3s'
                }}>
                  Email
                </label>
                <input
                  type="email"
                  style={{
                    width: '100%',
                    padding: isMobile ? '0.625rem 0.875rem' : '0.75rem 1rem',
                    fontSize: isMobile ? '0.875rem' : '1rem',
                    borderRadius: '0.5rem',
                    backgroundColor: inputBgColor,
                    border: `1px solid ${borderColor}`,
                    color: titleColor,
                    outline: 'none',
                    transition: 'border-color 0.2s, background-color 0.3s, color 0.3s'
                  }}
                  placeholder="ivan@example.com"
                  onFocus={(e) => e.currentTarget.style.borderColor = colorScheme.primary}
                  onBlur={(e) => e.currentTarget.style.borderColor = borderColor}
                />
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{
                  display: 'block',
                  fontSize: isMobile ? '0.875rem' : '1rem',
                  fontWeight: '500',
                  color: titleColor,
                  marginBottom: '0.5rem',
                  transition: 'color 0.3s'
                }}>
                  Сообщение
                </label>
                <textarea
                  rows={4}
                  style={{
                    width: '100%',
                    padding: isMobile ? '0.625rem 0.875rem' : '0.75rem 1rem',
                    fontSize: isMobile ? '0.875rem' : '1rem',
                    lineHeight: '1.625',
                    borderRadius: '0.5rem',
                    backgroundColor: inputBgColor,
                    border: `1px solid ${borderColor}`,
                    color: titleColor,
                    resize: 'none',
                    outline: 'none',
                    transition: 'border-color 0.2s, background-color 0.3s, color 0.3s',
                    fontFamily: 'inherit'
                  }}
                  placeholder="Расскажите о вашем проекте..."
                  onFocus={(e) => e.currentTarget.style.borderColor = colorScheme.primary}
                  onBlur={(e) => e.currentTarget.style.borderColor = borderColor}
                />
              </div>

              <SimpleButton>Отправить сообщение</SimpleButton>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

import React from 'react';
import { SimpleButton } from '../SimpleButton';
import { Check } from 'lucide-react';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';

interface PricingBlockProps {
  id?: string;
  data?: any;
}

export function PricingBlock({ id, data }: PricingBlockProps) {
  const { theme, color } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);

  const defaultData = {
    title: 'Тарифы',
    subtitle: 'Выберите план, который подходит именно вам',
    plans: [
      {
        name: 'Стартовый',
        price: '0',
        period: 'бесплатно',
        features: ['1 лендинг', 'Базовые блоки', 'Поддержка сообщества']
      },
      {
        name: 'Профессиональный',
        price: '1990',
        period: '₽/месяц',
        features: ['10 лендингов', 'Все блоки', 'Приоритетная поддержка', 'Кастомный домен'],
        highlighted: true
      },
      {
        name: 'Бизнес',
        price: '4990',
        period: '₽/месяц',
        features: ['Безлимит лендингов', 'Все блоки', 'VIP поддержка', 'White-label', 'API доступ']
      }
    ]
  };

  const content = {
    title: data?.title || defaultData.title,
    subtitle: data?.subtitle || defaultData.subtitle,
    plans: data?.plans || defaultData.plans
  };

  const bgColor = theme === 'dark' ? '#111827' : 'white';
  const cardBgColor = theme === 'dark' ? '#1f2937' : '#f9fafb';
  const borderColor = theme === 'dark' ? '#374151' : '#e5e7eb';
  const titleColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const subtitleColor = theme === 'dark' ? '#d1d5db' : '#4b5563';

  return (
    <section style={{
      width: '100%',
      backgroundColor: bgColor,
      transition: 'background-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '3rem 1rem' : '6rem 1.5rem'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: isMobile ? '2.5rem' : '4rem'
        }}>
          <h2 style={{
            fontSize: isMobile ? '1.875rem' : '2.25rem',
            fontWeight: '700',
            lineHeight: '1.2',
            color: titleColor,
            marginBottom: '1rem',
            transition: 'color 0.3s'
          }}>{content.title}</h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: subtitleColor,
            maxWidth: '42rem',
            margin: '0 auto',
            transition: 'color 0.3s'
          }}>
            {content.subtitle}
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: isMobile ? '1.5rem' : '2rem'
        }}>
          {content.plans.map((plan: any, index: number) => (
            <div
              key={index}
              style={{
                position: 'relative',
                backgroundColor: cardBgColor,
                padding: isMobile ? '1.5rem' : '2rem',
                borderRadius: '1rem',
                border: plan.highlighted ? `2px solid ${colorScheme.primary}` : `2px solid ${borderColor}`,
                transition: 'all 0.3s',
                boxShadow: plan.highlighted ? '0 20px 25px -5px rgba(0, 0, 0, 0.1)' : 'none',
                transform: plan.highlighted && !isMobile ? 'scale(1.05)' : 'scale(1)'
              }}
              onMouseEnter={(e) => {
                if (!plan.highlighted) {
                  e.currentTarget.style.borderColor = colorScheme.primary;
                }
              }}
              onMouseLeave={(e) => {
                if (!plan.highlighted) {
                  e.currentTarget.style.borderColor = borderColor;
                }
              }}
            >
              {plan.highlighted && (
                <div style={{
                  position: 'absolute',
                  top: '-1rem',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  backgroundColor: colorScheme.primary,
                  color: 'white',
                  padding: '0.25rem 1rem',
                  borderRadius: '9999px',
                  fontSize: '0.875rem',
                  fontWeight: '500'
                }}>
                  Популярный
                </div>
              )}
              
              <div style={{
                textAlign: 'center',
                marginBottom: '2rem'
              }}>
                <h3 style={{
                  fontSize: isMobile ? '1.25rem' : '1.5rem',
                  fontWeight: '600',
                  lineHeight: '1.375',
                  color: titleColor,
                  marginBottom: '1rem',
                  transition: 'color 0.3s'
                }}>{plan.name}</h3>
                <div style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'center',
                  gap: '0.25rem'
                }}>
                  <span style={{
                    fontSize: isMobile ? '2.5rem' : '3rem',
                    fontWeight: '700',
                    color: titleColor,
                    transition: 'color 0.3s'
                  }}>{plan.price}</span>
                  <span style={{
                    fontSize: isMobile ? '0.875rem' : '1rem',
                    color: subtitleColor,
                    transition: 'color 0.3s'
                  }}>{plan.period}</span>
                </div>
              </div>

              <ul style={{
                listStyle: 'none',
                padding: 0,
                margin: '0 0 2rem 0'
              }}>
                {plan.features.map((feature: string, featureIndex: number) => (
                  <li key={featureIndex} style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0.75rem',
                    marginBottom: '1rem'
                  }}>
                    <Check
                      style={{
                        color: colorScheme.primary,
                        flexShrink: 0,
                        marginTop: '0.125rem'
                      }}
                      size={20}
                    />
                    <span style={{
                      fontSize: isMobile ? '0.875rem' : '1rem',
                      lineHeight: '1.625',
                      color: subtitleColor,
                      transition: 'color 0.3s'
                    }}>{feature}</span>
                  </li>
                ))}
              </ul>

              <SimpleButton
                variant={plan.highlighted ? 'primary' : 'secondary'}
              >
                Выбрать план
              </SimpleButton>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
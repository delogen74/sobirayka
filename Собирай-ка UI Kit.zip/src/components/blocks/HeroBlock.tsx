import React, { useState } from 'react';
import { SimpleButton } from '../SimpleButton';
import { ArrowRight } from 'lucide-react';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';

interface HeroProps {
  id?: string;
  data?: any;
}

export function HeroBlock({ id, data }: HeroProps) {
  const { theme, color, isEditing, onTextEdit } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);
  
  const [content, setContent] = useState({
    title: 'Создайте идеальный лендинг за минуты',
    subtitle: 'Современный конструктор с готовыми блоками, адаптивной сеткой и гибкой системой дизайна',
    ctaPrimary: 'Начать бесплатно',
    ctaSecondary: 'Узнать больше'
  });

  const currentContent = {
    title: data?.title || content.title,
    subtitle: data?.subtitle || content.subtitle,
    ctaPrimary: data?.ctaPrimary || content.ctaPrimary,
    ctaSecondary: data?.ctaSecondary || content.ctaSecondary
  };

  const handleEdit = (field: string, value: string) => {
    if (id && onTextEdit) {
      onTextEdit(id, field, value);
    }
  };

  const bgColor = theme === 'dark' ? '#111827' : 'white';
  const titleColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const subtitleColor = theme === 'dark' ? '#d1d5db' : '#4b5563';

  return (
    <section style={{
      width: '100%',
      backgroundColor: bgColor,
      transition: 'background-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '3rem 1rem' : '6rem 1.5rem'
      }}>
        <div style={{
          maxWidth: '56rem',
          margin: '0 auto',
          textAlign: 'center'
        }}>
          {isEditing ? (
            <textarea
              value={currentContent.title}
              onChange={(e) => handleEdit('title', e.target.value)}
              style={{
                width: '100%',
                fontSize: isMobile ? '2rem' : '3rem',
                fontWeight: '700',
                lineHeight: '1.2',
                color: titleColor,
                backgroundColor: 'transparent',
                borderBottom: `2px dashed ${colorScheme.primary}`,
                padding: '0.5rem',
                textAlign: 'center',
                resize: 'none',
                outline: 'none',
                border: 'none',
                borderBottom: `2px dashed ${colorScheme.primary}`,
                fontFamily: 'inherit'
              }}
              rows={isMobile ? 3 : 2}
            />
          ) : (
            <h1 style={{
              fontSize: isMobile ? '2rem' : '3rem',
              fontWeight: '700',
              lineHeight: '1.2',
              color: titleColor,
              marginBottom: '1.5rem',
              transition: 'color 0.3s'
            }}>
              {currentContent.title}
            </h1>
          )}

          {isEditing ? (
            <textarea
              value={currentContent.subtitle}
              onChange={(e) => handleEdit('subtitle', e.target.value)}
              style={{
                width: '100%',
                fontSize: isMobile ? '1rem' : '1.25rem',
                lineHeight: '1.75',
                color: subtitleColor,
                backgroundColor: 'transparent',
                borderBottom: `1px dashed ${colorScheme.primary}`,
                padding: '0.5rem',
                textAlign: 'center',
                resize: 'none',
                marginTop: '1.5rem',
                outline: 'none',
                border: 'none',
                borderBottom: `1px dashed ${colorScheme.primary}`,
                fontFamily: 'inherit'
              }}
              rows={isMobile ? 3 : 2}
            />
          ) : (
            <p style={{
              fontSize: isMobile ? '1rem' : '1.25rem',
              lineHeight: '1.75',
              color: subtitleColor,
              marginBottom: '2.5rem',
              maxWidth: '42rem',
              margin: '0 auto 2.5rem',
              transition: 'color 0.3s'
            }}>
              {currentContent.subtitle}
            </p>
          )}

          <div style={{
            display: 'flex',
            flexDirection: isMobile ? 'column' : 'row',
            gap: '1rem',
            justifyContent: 'center',
            alignItems: 'center',
            flexWrap: 'wrap'
          }}>
            <SimpleButton size={isMobile ? 'md' : 'lg'} icon={!isMobile ? <ArrowRight size={20} /> : undefined}>
              {currentContent.ctaPrimary}
            </SimpleButton>
            <SimpleButton size={isMobile ? 'md' : 'lg'} variant="outline">
              {currentContent.ctaSecondary}
            </SimpleButton>
          </div>
        </div>
      </div>
    </section>
  );
}
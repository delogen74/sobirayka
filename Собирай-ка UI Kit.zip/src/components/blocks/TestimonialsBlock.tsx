import React from 'react';
import { Star } from 'lucide-react';
import { useTheme, getColorScheme } from '../../contexts/ThemeContext';
import { useResponsive } from '../../hooks/useResponsive';

interface TestimonialsBlockProps {
  id?: string;
  data?: any;
}

export function TestimonialsBlock({ id, data }: TestimonialsBlockProps) {
  const { theme, color } = useTheme();
  const { isMobile } = useResponsive();
  const colorScheme = getColorScheme(color);

  const defaultData = {
    title: 'Отзывы',
    subtitle: 'Что говорят наши клиенты',
    testimonials: [
      {
        name: 'Анна Петрова',
        role: 'Продакт-менеджер',
        content: 'Невероятно удобный инструмент! Смогла создать лендинг для нового продукта за пару часов.',
        rating: 5
      },
      {
        name: 'Дмитрий Смирнов',
        role: 'Основатель стартапа',
        content: 'Отличное соотношение цены и качества. Рекомендую всем, кто хочет быстро запустить проект.',
        rating: 5
      },
      {
        name: 'Мария Иванова',
        role: 'Дизайнер',
        content: 'Современный дизайн и отличная типографика. Все блоки выглядят профессионально.',
        rating: 5
      }
    ]
  };

  const content = {
    title: data?.title || defaultData.title,
    subtitle: data?.subtitle || defaultData.subtitle,
    testimonials: data?.testimonials || defaultData.testimonials
  };

  const bgColor = theme === 'dark' ? '#1f2937' : '#f9fafb';
  const cardBgColor = theme === 'dark' ? '#111827' : 'white';
  const borderColor = theme === 'dark' ? '#374151' : '#e5e7eb';
  const titleColor = theme === 'dark' ? '#f9fafb' : '#111827';
  const subtitleColor = theme === 'dark' ? '#d1d5db' : '#4b5563';
  const roleColor = theme === 'dark' ? '#9ca3af' : '#9ca3af';

  return (
    <section style={{
      width: '100%',
      backgroundColor: bgColor,
      transition: 'background-color 0.3s'
    }}>
      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: isMobile ? '3rem 1rem' : '6rem 1.5rem'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: isMobile ? '2.5rem' : '4rem'
        }}>
          <h2 style={{
            fontSize: isMobile ? '1.875rem' : '2.25rem',
            fontWeight: '700',
            lineHeight: '1.2',
            color: titleColor,
            marginBottom: '1rem',
            transition: 'color 0.3s'
          }}>{content.title}</h2>
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            lineHeight: '1.75',
            color: subtitleColor,
            maxWidth: '42rem',
            margin: '0 auto',
            transition: 'color 0.3s'
          }}>
            {content.subtitle}
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: isMobile ? '1.5rem' : '2rem'
        }}>
          {content.testimonials.map((testimonial: any, index: number) => (
            <div
              key={index}
              style={{
                backgroundColor: cardBgColor,
                padding: isMobile ? '1.5rem' : '2rem',
                borderRadius: '1rem',
                border: `1px solid ${borderColor}`,
                transition: 'all 0.3s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = colorScheme.primary;
                e.currentTarget.style.transform = 'translateY(-4px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = borderColor;
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{
                display: 'flex',
                gap: '0.25rem',
                marginBottom: '1rem'
              }}>
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    size={isMobile ? 18 : 20}
                    style={{
                      fill: colorScheme.primary,
                      color: colorScheme.primary
                    }}
                  />
                ))}
              </div>

              <p style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                lineHeight: '1.625',
                color: subtitleColor,
                marginBottom: '1.5rem',
                fontStyle: 'italic',
                transition: 'color 0.3s'
              }}>
                "{testimonial.content}"
              </p>

              <div>
                <p style={{
                  fontSize: isMobile ? '0.875rem' : '1rem',
                  fontWeight: '600',
                  color: titleColor,
                  marginBottom: '0.25rem',
                  transition: 'color 0.3s'
                }}>{testimonial.name}</p>
                <p style={{
                  fontSize: '0.875rem',
                  color: roleColor
                }}>{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
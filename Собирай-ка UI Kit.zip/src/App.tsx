import React, { useState, useEffect } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TouchBackend } from 'react-dnd-touch-backend';
import { HeaderBlock } from './components/blocks/HeaderBlock';
import { HeroBlock } from './components/blocks/HeroBlock';
import { ValuePropsBlock } from './components/blocks/ValuePropsBlock';
import { PricingBlock } from './components/blocks/PricingBlock';
import { TestimonialsBlock } from './components/blocks/TestimonialsBlock';
import { ContactBlock } from './components/blocks/ContactBlock';
import { FooterBlock } from './components/blocks/FooterBlock';
import { BlockLibrary } from './components/BlockLibrary';
import { ThemeControls } from './components/ThemeControls';
import { SimpleButton } from './components/SimpleButton';
import { Documentation } from './components/Documentation';
import { ThemeProvider } from './contexts/ThemeContext';
import { useResponsive } from './hooks/useResponsive';
import { Eye, Code, ArrowLeft, Trash2, GripVertical, Edit3, BookOpen, Menu, X } from 'lucide-react';

interface Block {
  id: string;
  type: string;
  data?: any;
}

type ViewMode = 'builder' | 'preview' | 'documentation';

const ItemType = 'BLOCK';

interface DraggableBlockProps {
  block: Block;
  index: number;
  moveBlock: (dragIndex: number, hoverIndex: number) => void;
  removeBlock: (blockId: string) => void;
  children: React.ReactNode;
  isMobile: boolean;
}

function DraggableBlock({ block, index, moveBlock, removeBlock, children, isMobile }: DraggableBlockProps) {
  const [{ isDragging }, drag, preview] = useDrag({
    type: ItemType,
    item: { index, id: block.id },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ItemType,
    hover: (item: { index: number; id: string }) => {
      if (item.index !== index) {
        moveBlock(item.index, index);
        item.index = index;
      }
    },
  });

  return (
    <div
      ref={(node) => preview(drop(node))}
      style={{
        position: 'relative',
        opacity: isDragging ? 0.5 : 1,
        transition: 'opacity 0.2s'
      }}
    >
      <div style={{
        position: 'absolute',
        top: isMobile ? '0.5rem' : '1rem',
        right: isMobile ? '0.5rem' : '1rem',
        zIndex: 10,
        display: 'flex',
        gap: '0.5rem'
      }}>
        <button
          ref={drag}
          style={{
            padding: isMobile ? '0.375rem' : '0.5rem',
            backgroundColor: '#6b7280',
            color: 'white',
            borderRadius: '0.5rem',
            boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
            transition: 'background-color 0.2s',
            border: 'none',
            cursor: 'move',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#4b5563'}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#6b7280'}
          aria-label="Переместить блок"
        >
          <GripVertical size={isMobile ? 16 : 18} />
        </button>
        <button
          onClick={() => removeBlock(block.id)}
          style={{
            padding: isMobile ? '0.375rem' : '0.5rem',
            backgroundColor: '#ef4444',
            color: 'white',
            borderRadius: '0.5rem',
            boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
            transition: 'background-color 0.2s',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#ef4444'}
          aria-label="Удалить блок"
        >
          <Trash2 size={isMobile ? 16 : 18} />
        </button>
      </div>
      {children}
    </div>
  );
}

function AppContent() {
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [color, setColor] = useState<'blue' | 'green' | 'purple'>('blue');
  const [viewMode, setViewMode] = useState<ViewMode>('builder');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [blockData, setBlockData] = useState<{ [key: string]: any }>({});
  const { isMobile, isTablet } = useResponsive();

  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false);
    } else {
      setIsSidebarOpen(true);
    }
  }, [isMobile]);

  const addBlock = (blockType: string) => {
    const newBlock: Block = {
      id: `${blockType}-${Date.now()}`,
      type: blockType
    };
    setBlocks([...blocks, newBlock]);
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  };

  const removeBlock = (blockId: string) => {
    setBlocks(blocks.filter(block => block.id !== blockId));
  };

  const moveBlock = (dragIndex: number, hoverIndex: number) => {
    const dragBlock = blocks[dragIndex];
    const newBlocks = [...blocks];
    newBlocks.splice(dragIndex, 1);
    newBlocks.splice(hoverIndex, 0, dragBlock);
    setBlocks(newBlocks);
  };

  const handleTextEdit = (blockId: string, field: string, value: string) => {
    setBlockData(prev => ({
      ...prev,
      [blockId]: {
        ...prev[blockId],
        [field]: value
      }
    }));
  };

  const hasHeader = blocks.some(block => block.type === 'header');
  const hasFooter = blocks.some(block => block.type === 'footer');

  const renderBlock = (block: Block, showControls: boolean = false) => {
    const blockComponents: { [key: string]: React.ComponentType<any> } = {
      header: HeaderBlock,
      hero: HeroBlock,
      valueProps: ValuePropsBlock,
      pricing: PricingBlock,
      testimonials: TestimonialsBlock,
      contact: ContactBlock,
      footer: FooterBlock
    };

    const BlockComponent = blockComponents[block.type];
    if (!BlockComponent) return null;

    const blockProps = {
      id: block.id,
      data: blockData[block.id]
    };

    if (showControls) {
      return (
        <DraggableBlock
          key={block.id}
          block={block}
          index={blocks.findIndex(b => b.id === block.id)}
          moveBlock={moveBlock}
          removeBlock={removeBlock}
          isMobile={isMobile}
        >
          <BlockComponent {...blockProps} />
        </DraggableBlock>
      );
    }

    return <BlockComponent key={block.id} {...blockProps} />;
  };

  const showDocumentation = () => {
    setViewMode('documentation');
  };

  if (viewMode === 'documentation') {
    return (
      <ThemeProvider theme={theme} color={color} isEditing={false}>
        <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6' }}>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            zIndex: 50,
            backgroundColor: '#f9fafb',
            borderBottom: '1px solid #e5e7eb',
            boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
          }}>
            <div style={{
              maxWidth: '80rem',
              margin: '0 auto',
              padding: isMobile ? '0.75rem 1rem' : '1rem 1.5rem'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '1rem',
                flexWrap: isMobile ? 'wrap' : 'nowrap'
              }}>
                <SimpleButton
                  variant="ghost"
                  icon={<ArrowLeft size={isMobile ? 18 : 20} />}
                  onClick={() => setViewMode('builder')}
                >
                  {isMobile ? 'Назад' : 'Вернуться к конструктору'}
                </SimpleButton>
                <ThemeControls
                  theme={theme}
                  color={color}
                  onThemeChange={setTheme}
                  onColorChange={setColor}
                />
              </div>
            </div>
          </div>

          <div style={{ paddingTop: isMobile ? '4rem' : '5rem' }}>
            <Documentation />
          </div>
        </div>
      </ThemeProvider>
    );
  }

  if (viewMode === 'preview') {
    return (
      <ThemeProvider theme={theme} color={color} isEditing={false}>
        <div style={{ minHeight: '100vh', backgroundColor: 'white' }}>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            zIndex: 50,
            backgroundColor: '#f9fafb',
            borderBottom: '1px solid #e5e7eb',
            boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
          }}>
            <div style={{
              maxWidth: '80rem',
              margin: '0 auto',
              padding: isMobile ? '0.75rem 1rem' : '1rem 1.5rem'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '1rem',
                flexWrap: isMobile ? 'wrap' : 'nowrap'
              }}>
                <SimpleButton
                  variant="ghost"
                  icon={<ArrowLeft size={isMobile ? 18 : 20} />}
                  onClick={() => setViewMode('builder')}
                >
                  {isMobile ? 'Назад' : 'Вернуться к конструктору'}
                </SimpleButton>
                <ThemeControls
                  theme={theme}
                  color={color}
                  onThemeChange={setTheme}
                  onColorChange={setColor}
                />
              </div>
            </div>
          </div>

          <div style={{ paddingTop: isMobile ? '4rem' : '5rem' }}>
            {blocks.length === 0 ? (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '100vh',
                padding: '2rem'
              }}>
                <div style={{ textAlign: 'center' }}>
                  <p style={{
                    color: '#4b5563',
                    fontSize: isMobile ? '1rem' : '1.125rem'
                  }}>
                    Добавьте блоки для предпросмотра
                  </p>
                </div>
              </div>
            ) : (
              blocks.map(block => renderBlock(block))
            )}
          </div>
        </div>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={theme} color={color} isEditing={isEditing} onTextEdit={handleTextEdit}>
      <div style={{
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        backgroundColor: 'white'
      }}>
        {/* Header */}
        <div style={{
          flexShrink: 0,
          backgroundColor: '#f9fafb',
          borderBottom: '1px solid #e5e7eb',
          boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
        }}>
          <div style={{
            padding: isMobile ? '0.75rem 1rem' : '1rem 1.5rem'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '1rem',
              flexWrap: isMobile ? 'wrap' : 'nowrap'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                {isMobile && (
                  <button
                    onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                    style={{
                      padding: '0.5rem',
                      borderRadius: '0.5rem',
                      backgroundColor: '#f3f4f6',
                      border: '1px solid #e5e7eb',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center'
                    }}
                  >
                    {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
                  </button>
                )}
                <div>
                  <h1 style={{
                    fontSize: isMobile ? '1.5rem' : '2.25rem',
                    fontWeight: '700',
                    lineHeight: isMobile ? '2rem' : '2.5rem',
                    color: '#111827',
                    margin: 0
                  }}>
                    {isMobile ? 'UI Kit' : 'Конструктор для СОГАЗ'}
                  </h1>
                  {!isMobile && (
                    <p style={{
                      fontSize: '0.875rem',
                      color: '#4b5563',
                      marginTop: '0.25rem',
                      marginBottom: 0
                    }}>
                      Конструктор "Собирай-ка" для очень быстрого создания лендингов
                    </p>
                  )}
                </div>
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: isMobile ? '0.5rem' : '0.75rem',
                flexWrap: 'wrap'
              }}>
                {!isMobile && (
                  <ThemeControls
                    theme={theme}
                    color={color}
                    onThemeChange={setTheme}
                    onColorChange={setColor}
                  />
                )}
                <SimpleButton
                  variant={isEditing ? "primary" : "ghost"}
                  icon={<Edit3 size={isMobile ? 18 : 20} />}
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isMobile ? '' : (isEditing ? 'Готово' : 'Редактировать')}
                </SimpleButton>
                <SimpleButton
                  variant="ghost"
                  icon={<BookOpen size={isMobile ? 18 : 20} />}
                  onClick={showDocumentation}
                >
                  {isMobile ? '' : 'Документация'}
                </SimpleButton>
                <SimpleButton
                  variant="primary"
                  icon={<Eye size={isMobile ? 18 : 20} />}
                  onClick={() => setViewMode('preview')}
                >
                  {isMobile ? '' : 'Предпросмотр'}
                </SimpleButton>
              </div>
            </div>
            {isMobile && (
              <div style={{ marginTop: '0.75rem' }}>
                <ThemeControls
                  theme={theme}
                  color={color}
                  onThemeChange={setTheme}
                  onColorChange={setColor}
                />
              </div>
            )}
          </div>
        </div>

        <div style={{
          flex: 1,
          display: 'flex',
          overflow: 'hidden',
          position: 'relative'
        }}>
          {/* Sidebar */}
          {isMobile ? (
            // Mobile: Overlay sidebar
            isSidebarOpen && (
              <>
                <div
                  onClick={() => setIsSidebarOpen(false)}
                  style={{
                    position: 'fixed',
                    inset: 0,
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    zIndex: 40
                  }}
                />
                <div style={{
                  position: 'fixed',
                  left: 0,
                  top: 0,
                  bottom: 0,
                  width: '80%',
                  maxWidth: '20rem',
                  backgroundColor: 'white',
                  borderRight: '1px solid #e5e7eb',
                  zIndex: 50,
                  overflowY: 'auto'
                }}>
                  <BlockLibrary
                    onAddBlock={addBlock}
                    hasHeader={hasHeader}
                    hasFooter={hasFooter}
                  />
                </div>
              </>
            )
          ) : (
            // Desktop: Normal sidebar
            <div style={{
              width: isSidebarOpen ? '20rem' : '0',
              flexShrink: 0,
              borderRight: '1px solid #e5e7eb',
              transition: 'all 0.3s',
              overflow: 'hidden'
            }}>
              <BlockLibrary
                onAddBlock={addBlock}
                hasHeader={hasHeader}
                hasFooter={hasFooter}
              />
            </div>
          )}

          {/* Main Content */}
          <div style={{
            flex: 1,
            overflowY: 'auto',
            backgroundColor: '#f3f4f6'
          }}>
            {blocks.length === 0 ? (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
                padding: isMobile ? '1rem' : '2rem'
              }}>
                <div style={{
                  textAlign: 'center',
                  maxWidth: '28rem'
                }}>
                  <div style={{
                    width: isMobile ? '3rem' : '4rem',
                    height: isMobile ? '3rem' : '4rem',
                    backgroundColor: '#dbeafe',
                    borderRadius: '1rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 1.5rem'
                  }}>
                    <Code size={isMobile ? 24 : 32} style={{ color: '#3b82f6' }} />
                  </div>
                  <h2 style={{
                    fontSize: isMobile ? '1.5rem' : '1.875rem',
                    fontWeight: '700',
                    lineHeight: isMobile ? '2rem' : '2.25rem',
                    color: '#111827',
                    marginBottom: '1rem'
                  }}>
                    Начните создание лендинга
                  </h2>
                  <p style={{
                    fontSize: isMobile ? '0.875rem' : '1rem',
                    lineHeight: '1.625',
                    color: '#4b5563',
                    marginBottom: '1.5rem'
                  }}>
                    {isMobile 
                      ? 'Нажмите на кнопку меню, чтобы добавить блоки'
                      : 'Выберите блоки из библиотеки слева, чтобы начать построение вашего лендинга. Вы можете добавлять неограниченное количество блоков.'
                    }
                  </p>
                </div>
              </div>
            ) : (
              <div style={{ maxWidth: '100%' }}>
                {blocks.map(block => renderBlock(block, true))}
              </div>
            )}
          </div>
        </div>
      </div>
    </ThemeProvider>
  );
}

export default function App() {
  const isMobileDevice = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  
  return (
    <DndProvider backend={isMobileDevice ? TouchBackend : HTML5Backend}>
      <AppContent />
    </DndProvider>
  );
}